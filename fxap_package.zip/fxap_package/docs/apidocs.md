## Base URL

```
https://api.allgamers.dev
```

## Authentication

```
Authorization: Bearer YOUR_API_KEY
```

## Endpoints

### POST /api/decrypt

Upload your resource file and license key.

**Headers:**
- `Authorization: Bearer {your_api_key}`
- `Content-Type: multipart/form-data`

**Body:**
- `file` - resource file (.zip)
- `license` - CFX license key

**Response:**
```json
{
  "success": true,
  "sessionId": "uuid-session-id",
  "status": "processing"
}
```

**Example:**
```bash
curl -X POST https://api.allgamers.dev/api/decrypt \
  -H "Authorization: Bearer ag_fxap_abc123def456" \
  -F "file=@resource.zip" \
  -F "license=ag_fxap_325982395235"
```

### GET /api/download/{sessionId}

Download your decrypted files.

**Headers:**
- `Authorization: Bearer {your_api_key}`

**Response:**
- **200:** ZIP file download
- **202:** Still processing
- **404:** Session not found
- **422:** Decryption failed

**Example:**
```bash
curl -X GET https://api.allgamers.dev/api/download/uuid-session-id \
  -H "Authorization: Bearer ag_fxap_abc123def456" \
  -O decrypted.zip
```

## Error Codes

```json
{
  "success": false,
  "error": "error_code"
}
```

- `invalid_api_key`
- `rate_limit_exceeded`
- `missing_file`
- `missing_license`
- `invalid_file_type`
- `session_not_found`
- `still_processing`

## Limits

- Max file size: 500 MB
- Supported: .zip
- Session timeout: 30 minutes

## Python Example

```python
import requests
import time

def decrypt_file(api_key, file_path, license):
    headers = {'Authorization': f'Bearer {api_key}'}
    
    with open(file_path, 'rb') as f:
        files = {'file': f}
        data = {'license': license}
        
        response = requests.post(
            'https://api.allgamers.dev/api/decrypt',
            headers=headers,
            files=files,
            data=data
        )
    
    if response.status_code != 200:
        print('Upload failed:', response.json())
        return
    
    session_id = response.json()['sessionId']
    print(f'Session: {session_id}')
    
    time.sleep(15)
    
    download_response = requests.get(
        f'https://api.allgamers.dev/api/download/{session_id}',
        headers=headers
    )
    
    if download_response.status_code == 200:
        with open('decrypted.zip', 'wb') as f:
            f.write(download_response.content)
        print('Download completed')
    else:
        print('Download failed:', download_response.json())

decrypt_file('ag_fxap_your_key', 'resource.zip', 'cfx_license')
```

## JavaScript Example

```javascript
const FormData = require('form-data');
const fs = require('fs');
const axios = require('axios');

async function decryptFile(apiKey, filePath, license) {
  try {
    const form = new FormData();
    form.append('file', fs.createReadStream(filePath));
    form.append('license', license);

    const response = await axios.post('https://api.allgamers.dev/api/decrypt', form, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        ...form.getHeaders()
      }
    });

    const { sessionId } = response.data;
    console.log('Session:', sessionId);
    
    setTimeout(async () => {
      const downloadResponse = await axios.get(
        `https://api.allgamers.dev/api/download/${sessionId}`,
        {
          headers: { 'Authorization': `Bearer ${apiKey}` },
          responseType: 'stream'
        }
      );

      if (downloadResponse.status === 200) {
        downloadResponse.data.pipe(fs.createWriteStream('decrypted.zip'));
        console.log('Download completed');
      }
    }, 15000);

  } catch (error) {
    console.error('Error:', error.response?.data || error.message);
  }
}

decryptFile('ag_fxap_your_key', './resource.zip', 'cfx_license');
```