const express = require('express');
const path = require('path');
const fs = require('fs');
const config = require('./modules/config');

const app = express();
const PORT = 3000;

app.use(express.static('public'));

const downloadedFiles = new Set();

app.get('/download/:sessionId', (req, res) => {
  const sessionId = req.params.sessionId;
  
  if (!sessionId || typeof sessionId !== 'string' || sessionId.length < 10) {
    console.log(`Invalid session ID format: ${sessionId}`);
    return res.status(400).json({ 
      error: 'Invalid session ID format',
      code: 'INVALID_SESSION_ID'
    });
  }

  if (sessionId.includes('<') || sessionId.includes('>')) {
      console.log(`Invalid session ID format: ${sessionId}`);
      return res.status(400).json({ 
          error: 'Invalid session ID format',
          code: 'INVALID_SESSION_ID'
      });
  }
  
  const sessionDir = path.join(__dirname, '..', 'sessions', sessionId);
  const filePath = path.join(sessionDir, 'Output.zip');
  
  console.log(`Download request for session: ${sessionId}`);
  console.log(`Session directory: ${sessionDir}`);
  console.log(`File path: ${filePath}`);
  
  if (downloadedFiles.has(sessionId)) {
    console.log(`Session ${sessionId} already downloaded`);
    return res.status(410).json({ 
      error: 'File already downloaded and removed',
      code: 'ALREADY_DOWNLOADED'
    });
  }
  
  if (!fs.existsSync(sessionDir)) {
    console.log(`Session directory not found: ${sessionDir}`);
    return res.status(404).json({ 
      error: 'Session not found or expired',
      code: 'SESSION_NOT_FOUND'
    });
  }
  
  if (!fs.existsSync(filePath)) {
    console.log(`Output file not found: ${filePath}`);
    return res.status(404).json({ 
      error: 'File not ready or processing failed',
      code: 'FILE_NOT_READY'
    });
  }
  
  try {
    const stats = fs.statSync(filePath);
    if (stats.size === 0) {
      console.log(`Empty file detected: ${filePath}`);
      return res.status(422).json({ 
        error: 'File is empty or corrupted',
        code: 'EMPTY_FILE'
      });
    }
    console.log(`File size: ${stats.size} bytes`);
  } catch (error) {
    console.error(`Error checking file stats: ${error.message}`);
    return res.status(500).json({ 
      error: 'File system error',
      code: 'FILE_SYSTEM_ERROR'
    });
  }
  
  const filename = `decrypted_${sessionId}.zip`;
  console.log(`Starting download: ${filename}`);
  
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Cache-Control', 'no-cache');
  
  res.download(filePath, filename, (err) => {
    if (err) {
      console.error(`Download error for session ${sessionId}:`, err);
      if (!res.headersSent) {
        return res.status(500).json({ 
          error: 'Download failed',
          code: 'DOWNLOAD_ERROR',
          details: err.message
        });
      }
    } else {
      console.log(`Download completed successfully for session: ${sessionId}`);
      downloadedFiles.add(sessionId);
      
      setTimeout(() => {
        try {
          if (fs.existsSync(sessionDir)) {
            fs.rmSync(sessionDir, { recursive: true, force: true });
            console.log(`Session ${sessionId} cleaned up after download`);
          }
          downloadedFiles.delete(sessionId);
        } catch (cleanupError) {
          console.error(`Cleanup error for session ${sessionId}:`, cleanupError);
        }
      }, 5000);
    }
  });
});

app.get('/status/:sessionId', (req, res) => {
  const sessionId = req.params.sessionId;
  const sessionDir = path.join(__dirname, '..', 'sessions', sessionId);
  const filePath = path.join(sessionDir, 'Output.zip');
  
  console.log(`Status check for session: ${sessionId}`);
  console.log(`Session dir exists: ${fs.existsSync(sessionDir)}`);
  console.log(`File exists: ${fs.existsSync(filePath)}`);
  console.log(`Downloaded files:`, Array.from(downloadedFiles));
  
  if (downloadedFiles.has(sessionId)) {
    console.log(`Session ${sessionId} marked as downloaded`);
    return res.json({ status: 'downloaded', available: false });
  }
  
  if (!fs.existsSync(sessionDir)) {
    console.log(`Session directory not found: ${sessionDir}`);
    return res.json({ status: 'not_found', available: false });
  }
  
  if (fs.existsSync(filePath)) {
    try {
      const stats = fs.statSync(filePath);
      console.log(`File size: ${stats.size} bytes`);
      
      if (stats.size > 0) {
        console.log(`Session ${sessionId} ready for download`);
        return res.json({ status: 'ready', available: true });
      } else {
        console.log(`File exists but is empty, still processing`);
        return res.json({ status: 'processing', available: false });
      }
    } catch (error) {
      console.error(`Error checking file stats:`, error);
      return res.json({ status: 'processing', available: false });
    }
  }
  
  try {
    const dirContents = fs.readdirSync(sessionDir);
    console.log(`Session directory contents:`, dirContents);
    
    if (dirContents.length > 0) {
      console.log(`Session ${sessionId} is processing`);
      return res.json({ status: 'processing', available: false });
    }
  } catch (error) {
    console.error(`Error reading session directory:`, error);
  }
  
  console.log(`Session ${sessionId} not found or failed`);
  return res.json({ status: 'not_found', available: false });
});

function startServer() {
  return new Promise((resolve) => {
    const server = app.listen(PORT, () => {
      console.log(`File server running on port ${PORT}`);
      resolve(server);
    });
  });
}

module.exports = { startServer, app };
