const express = require('express');
const multer = require('multer');

const { validateApiKey, updateKeyUsage } = require('./auth');
const { checkRateLimit } = require('./rate-limit');
const DecryptAPI = require('./decrypt-api');

const app = express();

app.use(express.json({ limit: '500mb' }));
app.use(express.urlencoded({ limit: '500mb', extended: true }));

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 500 * 1024 * 1024 }
});
const decryptAPI = new DecryptAPI();

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      error: 'missing_auth_header'
    });
  }

  const apiKey = authHeader.substring(7);
  const keyData = validateApiKey(apiKey);
  
  if (!keyData) {
    return res.status(401).json({
      success: false,
      error: 'invalid_api_key'
    });
  }

  const rateCheck = checkRateLimit(apiKey);
  
  if (!rateCheck.allowed) {
    return res.status(429).json({
      success: false,
      error: rateCheck.reason
    });
  }

  req.apiKey = apiKey;
  req.keyData = keyData;
  next();
}

app.post('/api/decrypt', authMiddleware, upload.single('file'), async (req, res) => {
  try {
    const { license } = req.body;
    const file = req.file;

    if (!file) {
      return res.status(400).json({
        success: false,
        error: 'missing_file'
      });
    }

    if (!license) {
      return res.status(400).json({
        success: false,
        error: 'missing_license'
      });
    }

    const allowedTypes = ['.zip', '.fxap'];
    const fileExt = file.originalname.toLowerCase().substring(file.originalname.lastIndexOf('.'));
    
    if (!allowedTypes.includes(fileExt)) {
      return res.status(400).json({
        success: false,
        error: 'invalid_file_type'
      });
    }

    updateKeyUsage(req.apiKey);
    
    const clientIP = req.headers['x-forwarded-for'] || 
                     req.headers['x-real-ip'] || 
                     req.connection.remoteAddress || 
                     req.socket.remoteAddress ||
                     (req.connection.socket ? req.connection.socket.remoteAddress : null) ||
                     req.ip;
    
    const result = await decryptAPI.startDecryption(file, license, req.apiKey, clientIP);
    
    res.json({
      success: true,
      sessionId: result.sessionId,
      status: result.status,
      message: 'Decryption started. Use the session ID to check status and download results.'
    });

  } catch (error) {
    console.error('API decrypt error:', error);
    
    let statusCode = 500;
    let errorCode = 'processing_failed';
    
    if (error.message.includes('capacity')) {
      statusCode = 503;
      errorCode = 'server_busy';
    } else if (error.message.includes('CFX Key') || error.message.includes('License')) {
      statusCode = 400;
      errorCode = 'invalid_license';
    } else if (error.message.includes('Keymaster')) {
      statusCode = 502;
      errorCode = 'keymaster_error';
    }
    
    res.status(statusCode).json({
      success: false,
      error: errorCode,
      message: error.message,
      details: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

app.get('/api/download/:sessionId', authMiddleware, (req, res) => {
  try {
    const { sessionId } = req.params;
    
    const session = decryptAPI.getSessionStatus(sessionId);
    
    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'session_not_found'
      });
    }

    if (session.status === 'processing') {
      return res.status(202).json({
        success: false,
        error: 'still_processing'
      });
    }

    if (session.status === 'failed') {
      return res.status(422).json({
        success: false,
        error: 'processing_failed',
        message: session.error
      });
    }

    const filePath = decryptAPI.getSessionFile(sessionId);
    
    if (!filePath) {
      return res.status(404).json({
        success: false,
        error: 'file_not_found'
      });
    }

    const filename = `decrypted_${sessionId}.zip`;
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    
    res.download(filePath, filename, (err) => {
      if (!err) {
        setTimeout(() => {
          decryptAPI.cleanupSession(sessionId);
        }, 5000);
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'download_failed',
      message: error.message
    });
  }
});

function startApiServer(port = 3001) {
  return new Promise((resolve) => {
    const server = app.listen(port, () => {
      console.log(`API server running on port ${port}`);
      console.log(`Worker pool initialized with 6 workers for parallel processing`);
      resolve(server);
    });

    process.on('SIGINT', async () => {
      console.log('Shutting down API server...');
      await decryptAPI.shutdown();
      server.close(() => {
        process.exit(0);
      });
    });

    process.on('SIGTERM', async () => {
      console.log('Shutting down API server...');
      await decryptAPI.shutdown();
      server.close(() => {
        process.exit(0);
      });
    });
  });
}

module.exports = { startApiServer, app };
