const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const WorkerPool = require('./worker-pool');

class DecryptAPI {
  constructor() {
    this.activeSessions = new Map();
    this.workerPool = new WorkerPool(
      path.join(__dirname, 'decrypt-worker.js'),
      6
    );
    this.maxConcurrentSessions = 6;
  }

  async startDecryption(file, cfxKey, apiKey, userIP = null) {
    const activeJobs = this.workerPool.getActiveJobsCount();
    const queueLength = this.workerPool.getQueueLength();
    
    if (activeJobs >= this.maxConcurrentSessions && queueLength > 10) {
      throw new Error(`Server is at maximum capacity. Active: ${activeJobs}, Queued: ${queueLength}. Please try again in a few minutes.`);
    }

    const sessionId = uuidv4();
    
    this.activeSessions.set(sessionId, {
      status: 'processing',
      apiKey,
      startTime: Date.now(),
      file: file.originalname,
      userIP,
      cfxKey,
      queuePosition: queueLength + 1
    });

    const workerData = {
      sessionId,
      file: {
        originalname: file.originalname,
        buffer: file.buffer.toString('base64')
      },
      cfxKey,
      apiKey,
      userIP
    };

    this.workerPool.execute(workerData)
      .then((result) => {
        this.activeSessions.set(sessionId, {
          ...this.activeSessions.get(sessionId),
          status: 'completed',
          zipPath: result.zipPath
        });

        setTimeout(() => {
          this.cleanupSession(sessionId);
        }, 30 * 60 * 1000);
      })
      .catch((error) => {
        console.error(`Session ${sessionId} failed:`, error);
        this.activeSessions.set(sessionId, {
          ...this.activeSessions.get(sessionId),
          status: 'failed',
          error: error.message
        });
      });

    return { 
      sessionId, 
      status: 'processing'
    };
  }

  getSessionStatus(sessionId) {
    return this.activeSessions.get(sessionId) || null;
  }

  getSessionFile(sessionId) {
    const session = this.activeSessions.get(sessionId);
    if (!session || session.status !== 'completed') {
      return null;
    }
    return session.zipPath;
  }

  cleanupSession(sessionId) {
    const session = this.activeSessions.get(sessionId);
    if (session) {
      const sessionDir = path.join(__dirname, '..', '..', 'sessions', sessionId);
      try {
        if (fs.existsSync(sessionDir)) {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        }
      } catch (error) {
        console.error('Cleanup error:', error);
      }
      this.activeSessions.delete(sessionId);
    }
  }

  async shutdown() {
    await this.workerPool.terminate();
  }
}

module.exports = DecryptAPI;