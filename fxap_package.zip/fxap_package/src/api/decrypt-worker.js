const { parentPort } = require('worker_threads');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const FiveMDecryptor = require('../modules/decryptor');
const { ensureEmptyDir, downloadTo, extractZipTo, findResourceDirs, dirFileCount, zipDirectory } = require('../modules/utils');
const { createBackup } = require('../modules/backup');

async function processDecryption(data) {
  const { file, cfxKey, apiKey, userIP, sessionId } = data;
  
  const sessionDir = path.join(__dirname, '..', '..', 'sessions', sessionId);
  const uploadsDir = path.join(sessionDir, 'Uploads');
  const resourcesDir = path.join(sessionDir, 'Resources');
  const outputDir = path.join(sessionDir, 'Output');
  const tempDir = path.join(sessionDir, 'TempCompiled');

  try {
    ensureEmptyDir(sessionDir);
    ensureEmptyDir(uploadsDir);
    ensureEmptyDir(resourcesDir);
    ensureEmptyDir(outputDir);
    ensureEmptyDir(tempDir);

    const uploadedPath = path.join(uploadsDir, file.originalname);
    fs.writeFileSync(uploadedPath, Buffer.from(file.buffer, 'base64'));

    const ext = path.extname(uploadedPath).toLowerCase();
    if (ext === '.zip') {
      extractZipTo(resourcesDir, uploadedPath);
    } else {
      throw new Error('Unsupported file type');
    }

    const decryptor = new FiveMDecryptor(outputDir, tempDir);
    const resourceDirs = findResourceDirs(resourcesDir);
    
    let successfulDecryptions = 0;
    let failedDecryptions = 0;
    const errors = [];

    for (const dir of resourceDirs) {
      const resourceName = path.basename(dir);
      try {
        await decryptor.decryptResource(cfxKey, dir, resourceName);
        successfulDecryptions++;
      } catch (error) {
        console.error(`Failed to decrypt resource ${resourceName}:`, error.message);
        failedDecryptions++;
        errors.push(`${resourceName}: ${error.message}`);
        
        if (error.message && error.message.includes('Keymaster')) {
          throw new Error(`Keymaster validation failed: ${error.message}. Please check your license key.`);
        }
      }
    }

    const filesProduced = dirFileCount(outputDir);
    if (filesProduced === 0) {
      throw new Error('No files decrypted');
    }

    const zipPath = path.join(sessionDir, 'Output.zip');
    await zipDirectory(outputDir, zipPath);

    const backupSuccess = createBackup(
      sessionId,
      apiKey,
      file.originalname,
      outputDir,
      cfxKey,
      userIP,
      true
    );
    
    if (backupSuccess) {
      console.log(`API backup created for session: ${sessionId}`);
    }

    return {
      status: 'completed',
      zipPath,
      sessionId
    };

  } catch (error) {
    throw error;
  }
}

parentPort.on('message', async (data) => {
  try {
    const result = await processDecryption(data);
    parentPort.postMessage({ type: 'result', data: result });
  } catch (error) {
    parentPort.postMessage({ 
      type: 'error', 
      error: error.message,
      sessionId: data.sessionId 
    });
  }
});
