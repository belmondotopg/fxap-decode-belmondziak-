const fs = require('fs');
const path = require('path');

let discordLogger = null;

function setDiscordLogger(logger) {
  discordLogger = logger;
}

const DB_PATH = path.join(__dirname, '..', 'database', 'api-keys.json');

function loadApiKeys() {
  try {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return { keys: {} };
  }
}

function checkRateLimit(apiKey) {
  const db = loadApiKeys();
  const keyData = db.keys[apiKey];
  
  if (!keyData || !keyData.isActive) {
    return { allowed: false, reason: 'invalid_key' };
  }
  
  if (keyData.subscriptionType === 'monthly' && keyData.expiresAt) {
    const now = new Date();
    const expiryDate = new Date(keyData.expiresAt);
    
    if (now > expiryDate) {
      return { allowed: false, reason: 'subscription_expired' };
    }
  }
  
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const lastUsed = keyData.lastUsed ? new Date(keyData.lastUsed) : null;
  
  if (!keyData.hourlyRequestCount) {
    keyData.hourlyRequestCount = 0;
    keyData.hourlyResetTime = Date.now();
  }
  
  if (Date.now() - keyData.hourlyResetTime > 60 * 60 * 1000) {
    keyData.hourlyRequestCount = 0;
    keyData.hourlyResetTime = Date.now();
  }
  
      if (keyData.hourlyRequestCount >= 100) {
      if (discordLogger) {
        discordLogger.logRateLimitExceeded(apiKey, 'hourly_rate_limit_exceeded');
      }
      return { allowed: false, reason: 'hourly_rate_limit_exceeded' };
    }
    
    return { allowed: true };
}

module.exports = {
  checkRateLimit,
  setDiscordLogger
};