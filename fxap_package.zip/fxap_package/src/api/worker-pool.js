const { Worker } = require('worker_threads');
const EventEmitter = require('events');
const path = require('path');

class WorkerPool extends EventEmitter {
  constructor(workerScript, poolSize = 5) {
    super();
    this.workerScript = workerScript;
    this.poolSize = poolSize;
    this.workers = [];
    this.freeWorkers = [];
    this.queue = [];
    this.activeJobs = new Map();
    this.init();
  }

  init() {
    for (let i = 0; i < this.poolSize; i++) {
      this.createWorker();
    }
  }

  createWorker() {
    const worker = new Worker(this.workerScript);
    const workerId = this.workers.length;
    
    worker.on('message', (message) => {
      if (message.type === 'result' || message.type === 'error') {
        const job = this.activeJobs.get(workerId);
        if (job) {
          if (message.type === 'error') {
            job.reject(new Error(message.error));
          } else {
            job.resolve(message.data);
          }
          this.activeJobs.delete(workerId);
        }
        
        this.freeWorkers.push(workerId);
        this.processQueue();
      }
    });

    worker.on('error', (error) => {
      console.error(`Worker ${workerId} error:`, error);
      const job = this.activeJobs.get(workerId);
      if (job) {
        job.reject(error);
        this.activeJobs.delete(workerId);
      }
      
      this.workers[workerId] = null;
      this.createWorker();
    });

    worker.on('exit', (code) => {
      if (code !== 0) {
        console.error(`Worker ${workerId} exited with code ${code}`);
        const job = this.activeJobs.get(workerId);
        if (job) {
          job.reject(new Error(`Worker exited with code ${code}`));
          this.activeJobs.delete(workerId);
        }
        
        this.workers[workerId] = null;
        this.createWorker();
      }
    });

    this.workers.push(worker);
    this.freeWorkers.push(workerId);
  }

  async execute(data) {
    return new Promise((resolve, reject) => {
      const job = { data, resolve, reject };
      
      if (this.freeWorkers.length > 0) {
        this.runJob(job);
      } else {
        this.queue.push(job);
      }
    });
  }

  runJob(job) {
    const workerId = this.freeWorkers.shift();
    const worker = this.workers[workerId];
    
    if (!worker) {
      this.queue.unshift(job);
      return;
    }
    
    this.activeJobs.set(workerId, job);
    worker.postMessage(job.data);
  }

  processQueue() {
    while (this.queue.length > 0 && this.freeWorkers.length > 0) {
      const job = this.queue.shift();
      this.runJob(job);
    }
  }

  getActiveJobsCount() {
    return this.activeJobs.size;
  }

  getQueueLength() {
    return this.queue.length;
  }

  async terminate() {
    await Promise.all(this.workers.map(worker => worker?.terminate()));
    this.workers = [];
    this.freeWorkers = [];
    this.queue = [];
    this.activeJobs.clear();
  }
}

module.exports = WorkerPool;
