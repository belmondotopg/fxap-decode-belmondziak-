const fs = require('fs');
const path = require('path');
const axios = require('axios');
const chacha20 = require('chacha20');
const crypto = require('crypto');
const { exec } = require('child_process');
const config = require('./config');

class FiveMDecryptor {
  constructor(outputDir, tempDir) {
    this.outputDir = outputDir;
    this.tempDir = tempDir;
  }

  fileToHex(filePath) {
    return fs.readFileSync(filePath);
  }

  scanForId(buffer) {
    return parseInt(buffer.slice(74, 78).toString('hex'), 16);
  }

  verifyEncrypted(filePath) {
    const buffer = this.fileToHex(filePath);
    return buffer.slice(0, 4).equals(config.HEADERS.FXAP_HEADER);
  }

  decryptFile(filePath, key) {
    const buffer = this.fileToHex(filePath);

    if (buffer.slice(0, 4).equals(config.HEADERS.FXAP_HEADER)) {
      const iv = buffer.slice(74, 86);
      const encrypted = buffer.slice(86);
      return chacha20.decrypt(key, iv, encrypted);
    }

    return null;
  }

  decryptBuffer(hexData, key, bufferPtr = null, ivPtr = null) {
    if (!hexData) return null;

    let iv = hexData.slice(80, 92);
    let encrypted = hexData.slice(92);
    
    if (bufferPtr && ivPtr) {
      iv = hexData.slice(ivPtr, ivPtr + 12);
      encrypted = hexData.slice(bufferPtr);
    }

    return chacha20.decrypt(key, iv, encrypted);
  }

  calculateClientKey(grantsClk) {
    const iv = grantsClk.slice(0, 16);
    const encrypted = grantsClk.slice(16);
    const decipher = crypto.createDecipheriv('aes-256-cbc', config.CRYPTO_KEYS.AES_KEY, iv);

    let decrypted = decipher.update(encrypted);
    decrypted = Buffer.concat([decrypted, decipher.final()]);

    return decrypted;
  }

  async processLuaFile(decryptedBuffer, outputPath, resourceName, file) {
      const tmpPath = path.join(this.tempDir, `${resourceName}/${file}c`);
      fs.mkdirSync(path.dirname(tmpPath), { recursive: true });
      fs.writeFileSync(tmpPath, decryptedBuffer);

      const finalPath = outputPath;
      fs.mkdirSync(path.dirname(finalPath), { recursive: true });

      console.log("Processing Lua file: " + tmpPath);

      const decompilerPath = path.join(__dirname, '..', '..', config.PATHS.DECOMPILER);
      const asmPath = tmpPath.replace('.luac', '.asm');
      const fixedPath = tmpPath.replace('.luac', '_fixed.luac');

      try {
          await this.execSilent(`java -jar "${decompilerPath}" --disassemble "${tmpPath}" > "${asmPath}"`);
          
          try {
              await this.execSilent(`java -jar "${decompilerPath}" --assemble "${asmPath}" -o "${fixedPath}"`);
              
              await this.execSilent(`java -jar "${decompilerPath}" "${fixedPath}" > "${finalPath}"`);
              console.log("Lua file processed successfully with reassembly");
              
          } catch (assembleError) {
              if (assembleError.stderr && assembleError.stderr.includes('Unknown label:')) {
                  console.log("Found JMP errors, attempting to fix...");
                  
                  let asmContent = fs.readFileSync(asmPath, 'utf8');
                  const errorMatches = assembleError.stderr.match(/Unknown label: (\d+)/g);
                  
                  if (errorMatches) {
                      const fixedLabels = new Set();
                      
                      errorMatches.forEach(match => {
                          const labelNum = match.match(/\d+/)[0];
                          const regex = new RegExp(`jmp\\s+${labelNum}\\b`, 'g');
                          asmContent = asmContent.replace(regex, `jmp L${labelNum}`);
                          fixedLabels.add(labelNum);
                          console.log(`Fixed JMP ${labelNum} -> L${labelNum}`);
                      });
                      
                      fs.writeFileSync(asmPath, asmContent);
                      
                      try {
                          await this.execSilent(`java -jar "${decompilerPath}" --assemble "${asmPath}" -o "${fixedPath}"`);
                          await this.execSilent(`java -jar "${decompilerPath}" "${fixedPath}" > "${finalPath}"`);
                          console.log("Lua file processed successfully after JMP fixes");
                          
                      } catch (secondError) {
                          console.log("Second assembly failed, using direct decompilation:", secondError.message);
                          await this.execSilent(`java -jar "${decompilerPath}" "${tmpPath}" > "${finalPath}"`);
                      }
                  }
              } else {
                  console.log("Assembly failed with unknown error, using direct decompilation:", assembleError.message);
                  await this.execSilent(`java -jar "${decompilerPath}" "${tmpPath}" > "${finalPath}"`);
              }
          }
          
      } catch (error) {
          console.log("Lua processing failed:", error.message);
          await this.execSilent(`java -jar "${decompilerPath}" "${tmpPath}" > "${finalPath}"`);
      }
  }

  execSilent(command) {
      return new Promise((resolve, reject) => {
          exec(command, (error, stdout, stderr) => {
              if (error) {
                  reject(error);
              } else {
                  resolve({ stdout, stderr });
              }
          });
      });
  }
  
  async decryptResourceFile(resourcePath, file, decryptKey, resourceName, grantsClk) {
    const fullPath = path.join(resourcePath, file);
    const outputPath = path.join(this.outputDir, resourceName, file);
    
    if (!this.verifyEncrypted(fullPath)) {
      fs.mkdirSync(path.dirname(outputPath), { recursive: true });
      fs.writeFileSync(outputPath, this.fileToHex(fullPath));
      return;
    }

    const decryptedFile = this.decryptFile(fullPath, config.CRYPTO_KEYS.DEFAULT_KEY);
    let decryptedBuffer = this.decryptBuffer(decryptedFile, decryptKey);
    const alternativeKey = this.calculateClientKey(grantsClk);
    
    if (!decryptedBuffer) return;
    
    if (file.toLowerCase().endsWith('.lua')) {
      const luaHeaderHex = '1b4c7561540019930d0a1a0a040808785';
      const isLuaBytecode = decryptedBuffer.toString('hex').startsWith(luaHeaderHex);
      
      if (isLuaBytecode) {
        await this.processLuaFile(decryptedBuffer, outputPath, resourceName, file);
      } else {
        decryptedBuffer = this.decryptBuffer(decryptedFile, decryptKey, 90, 78);
        const isLuaBytecodeSecond = decryptedBuffer && decryptedBuffer.toString('hex').startsWith(luaHeaderHex);
        
        if (isLuaBytecodeSecond) {
          await this.processLuaFile(decryptedBuffer, outputPath, resourceName, file);
        } else {
          decryptedBuffer = this.decryptBuffer(decryptedFile, alternativeKey);
          await this.processLuaFile(decryptedBuffer, outputPath, resourceName, file);
        }
      }
    } else {
      fs.mkdirSync(path.dirname(outputPath), { recursive: true });
      fs.writeFileSync(outputPath, decryptedBuffer);
    }
  }

  getAllFiles(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });

    return entries.flatMap(entry => {
      const filePath = path.join(dir, entry.name);
      return entry.isDirectory() ? this.getAllFiles(filePath) : [filePath];
    });
  }

  checkBlacklist(fxapFile) {
    try {
      const blacklistPath = path.join(__dirname, '..', 'database', 'blacklist.json');
      if (!fs.existsSync(blacklistPath)) return false;
      
      const blacklist = JSON.parse(fs.readFileSync(blacklistPath, 'utf8'));
      if (!blacklist.enabled) return false;
      
      const fxapContent = fs.readFileSync(fxapFile).toString('hex');
      
      const isBlacklisted = blacklist.blacklisted_fxap_contents.some(item => 
        item.content.toLowerCase() === fxapContent.toLowerCase()
      );
      
      return isBlacklisted;
    } catch (error) {
      console.log('Blacklist check error:', error.message);
      return false;
    }
  }

  async validateKey(cfxKey) {
    const isFile = cfxKey.endsWith('txt');
    if (!cfxKey || (!cfxKey.startsWith('cfxk_') && !isFile)) {
      throw new Error('Invalid CFX Key');
    }
    
    if (isFile) {
      return { success: true, grants_token: fs.readFileSync(cfxKey, 'utf8') };
    }
    
    const { data, status } = await axios.get(`${config.KEYMASTER_URL}/${cfxKey}`, {
      headers: { 'User-Agent': 'CitizenFX/1' }
    });
    
    if (status !== 200 || !data.success || !data.grants_token) {
      throw new Error('Invalid Keymaster response');
    }
    
    return data;
  }

  async decryptResource(cfxKey, resourcePath, resourceName) {
    const fxapFile = path.join(resourcePath, '.fxap');
    if (!fs.existsSync(fxapFile)) return;
    
    if (this.checkBlacklist(fxapFile)) {
      throw new Error("You can't decrypt this resource");
    }
    
    const fxapBuffer = this.decryptFile(fxapFile, config.CRYPTO_KEYS.DEFAULT_KEY);
    if (!fxapBuffer) return;
    
    const resourceId = this.scanForId(fxapBuffer);
    console.log("Resource ID: " + resourceId);

    try {
      const keyData = await this.validateKey(cfxKey);
      const payload = JSON.parse(Buffer.from(keyData.grants_token.split('.')[1], 'base64').toString('utf-8'));
      
      if (!payload.grants[resourceId]) return;
      
      const decryptKey = Buffer.from(payload.grants[resourceId], 'hex');
      const grantsClk = Buffer.from(payload.grants_clk[resourceId], 'hex');
      const files = this.getAllFiles(resourcePath);
      
      const tasks = files.filter(f => !f.endsWith('.fxap')).map(f => {
        const relativePath = path.relative(resourcePath, f);
        return this.decryptResourceFile(resourcePath, relativePath, decryptKey, resourceName, grantsClk);
      });
      
      await Promise.all(tasks);
    } catch (error) {
      console.log('Keymaster error:', error.message);
    }
  }
}

module.exports = FiveMDecryptor;
