const { EmbedBuilder, WebhookClient } = require('discord.js');
const config = require('./config');

class DiscordLogger {
  constructor(client) {
    this.client = client;
    this.logChannel = null;
    this.webhookClient = null;
    this.initialized = false;
  }

  async initialize() {
    if (!config.LOGGING.ENABLED) {
      console.log('Discord logging is disabled in config');
      return;
    }

    try {
      const guild = this.client.guilds.cache.get(config.GUILD_ID);
      if (guild) {
        this.logChannel = guild.channels.cache.get(config.LOGGING.CHANNEL_ID);
        if (this.logChannel) {
          console.log(`Discord logging initialized for channel: ${this.logChannel.name}`);
          this.initialized = true;
          return;
        }
      }

      console.log('Direct channel access failed, logging will be disabled');
      this.initialized = false;
    } catch (error) {
      console.error('Failed to initialize Discord logging:', error);
      this.initialized = false;
    }
  }

  async log(eventType, data) {
    if (!config.LOGGING.ENABLED || !this.initialized || !config.LOGGING.EVENTS[eventType]) {
      return;
    }

    try {
      const embed = this.createEmbed(eventType, data);
      if (embed && this.logChannel) {
        await this.logChannel.send({ embeds: [embed] });
      }
    } catch (error) {
      console.error('Failed to send Discord log:', error);
    }
  }

  createEmbed(eventType, data) {
    const embed = new EmbedBuilder()
      .setTimestamp()
      .setFooter({ text: 'FXAP System Logger' });

    switch (eventType) {
      case 'DECRYPTION_START':
        embed
          .setTitle('Decryption Started')
          .setDescription(`**User:** ${data.userTag} (${data.userId})\n**File:** ${data.fileName}\n**Method:** ${data.method}`)
          .setColor(config.LOGGING.COLORS.INFO);
        break;

      case 'DECRYPTION_SUCCESS':
        embed
          .setTitle('Decryption Successful')
          .setDescription(`**User:** ${data.userTag} (${data.userId})\n**File:** ${data.fileName}\n**Session ID:** \`${data.sessionId}\`\n**Method:** ${data.method}`)
          .setColor(config.LOGGING.COLORS.SUCCESS);
        break;

      case 'DECRYPTION_FAILED':
        embed
          .setTitle('Decryption Failed')
          .setDescription(`**User:** ${data.userTag} (${data.userId})\n**File:** ${data.fileName}\n**Error:** ${data.error}\n**Method:** ${data.method}`)
          .setColor(config.LOGGING.COLORS.ERROR);
        break;

      case 'ACCESS_DENIED':
        embed
          .setTitle('Access Denied')
          .setDescription(`**User:** ${data.userTag} (${data.userId})\n**Reason:** ${data.reason}\n**IP:** ${data.ip || 'N/A'}`)
          .setColor(config.LOGGING.COLORS.WARNING);
        break;

      case 'SUBSCRIPTION_ADDED':
        embed
          .setTitle('Subscription Added')
          .setDescription(`**User:** ${data.userTag} (${data.userId})\n**Type:** ${data.type}\n**Duration:** ${data.duration}\n**Admin:** ${data.adminTag}`)
          .setColor(config.LOGGING.COLORS.SUCCESS);
        break;

      case 'SUBSCRIPTION_REMOVED':
        embed
          .setTitle('Subscription Removed')
          .setDescription(`**User:** ${data.userTag} (${data.userId})\n**Previous Type:** ${data.previousType}\n**Admin:** ${data.adminTag}`)
          .setColor(config.LOGGING.COLORS.WARNING);
        break;

      case 'CREDITS_ADDED':
        embed
          .setTitle('Credits Added')
          .setDescription(`**User:** ${data.userTag} (${data.userId})\n**Amount:** +${data.amount}\n**New Balance:** ${data.newBalance}\n**Admin:** ${data.adminTag}`)
          .setColor(config.LOGGING.COLORS.SUCCESS);
        break;

      case 'CREDITS_REMOVED':
        embed
          .setTitle('Credits Removed')
          .setDescription(`**User:** ${data.userTag} (${data.userId})\n**Amount:** -${data.amount}\n**New Balance:** ${data.newBalance}\n**Reason:** ${data.reason}`)
          .setColor(config.LOGGING.COLORS.INFO);
        break;

      case 'API_KEY_CREATED':
        embed
          .setTitle('API Key Created')
          .setDescription(`**Name:** ${data.name}\n**Type:** ${data.subscriptionType}\n**Admin:** ${data.adminTag}`)
          .setColor(config.LOGGING.COLORS.SUCCESS);
        break;

      case 'API_KEY_REMOVED':
        embed
          .setTitle('API Key Removed')
          .setDescription(`**Name:** ${data.name}\n**Admin:** ${data.adminTag}`)
          .setColor(config.LOGGING.COLORS.WARNING);
        break;

      case 'BACKUP_CREATED':
        embed
          .setTitle('Backup Created')
          .setDescription(`**User:** ${data.userName}\n**File:** ${data.fileName}\n**Type:** ${data.isApiRequest ? 'API' : 'Discord'}\n**IP:** ${data.ip || 'N/A'}`)
          .setColor(config.LOGGING.COLORS.SUCCESS_DARK);
        break;

      case 'RATE_LIMIT_EXCEEDED':
        embed
          .setTitle('Rate Limit Exceeded')
          .setDescription(`**API Key:** ${data.apiKey.substring(0, 20)}...\n**Reason:** ${data.reason}\n**IP:** ${data.ip || 'N/A'}`)
          .setColor(config.LOGGING.COLORS.ERROR_DARK);
        break;

      default:
        embed
          .setTitle('System Event')
          .setDescription(`**Event:** ${eventType}\n**Data:** ${JSON.stringify(data, null, 2)}`)
          .setColor(config.LOGGING.COLORS.INFO);
    }

    return embed;
  }

  async logDecryptionStart(userTag, userId, fileName, method = 'Discord') {
    await this.log('DECRYPTION_START', { userTag, userId, fileName, method });
  }

  async logDecryptionSuccess(userTag, userId, fileName, sessionId, method = 'Discord') {
    await this.log('DECRYPTION_SUCCESS', { userTag, userId, fileName, sessionId, method });
  }

  async logDecryptionFailed(userTag, userId, fileName, error, method = 'Discord') {
    await this.log('DECRYPTION_FAILED', { userTag, userId, fileName, error, method });
  }

  async logAccessDenied(userTag, userId, reason, ip = null) {
    await this.log('ACCESS_DENIED', { userTag, userId, reason, ip });
  }

  async logSubscriptionAdded(userTag, userId, type, duration, adminTag) {
    await this.log('SUBSCRIPTION_ADDED', { userTag, userId, type, duration, adminTag });
  }

  async logSubscriptionRemoved(userTag, userId, previousType, adminTag) {
    await this.log('SUBSCRIPTION_REMOVED', { userTag, userId, previousType, adminTag });
  }

  async logCreditsAdded(userTag, userId, amount, newBalance, adminTag) {
    await this.log('CREDITS_ADDED', { userTag, userId, amount, newBalance, adminTag });
  }

  async logCreditsRemoved(userTag, userId, amount, newBalance, reason) {
    await this.log('CREDITS_REMOVED', { userTag, userId, amount, newBalance, reason });
  }

  async logApiKeyCreated(name, subscriptionType, adminTag) {
    await this.log('API_KEY_CREATED', { name, subscriptionType, adminTag });
  }

  async logApiKeyRemoved(name, adminTag) {
    await this.log('API_KEY_REMOVED', { name, adminTag });
  }

  async logBackupCreated(userName, fileName, isApiRequest, ip = null) {
    await this.log('BACKUP_CREATED', { userName, fileName, isApiRequest, ip });
  }

  async logRateLimitExceeded(apiKey, reason, ip = null) {
    await this.log('RATE_LIMIT_EXCEEDED', { apiKey, reason, ip });
  }
}

module.exports = DiscordLogger;
