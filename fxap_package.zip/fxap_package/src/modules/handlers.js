const fs = require('fs');
const path = require('path');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const FiveMDecryptor = require('./decryptor');
const { ensureEmptyDir, downloadTo, extractZipTo, findResourceDirs, dirFileCount, zipDirectory } = require('./utils');
const { getUserCredits, addCredits, removeCredits, hasEnoughCredits, setCredits, getUserSubscription, hasValidSubscription, setSubscription, removeSubscription, canUserDecrypt } = require('./credits');
const { createBackup, cleanOldBackups } = require('./backup');
const { validateApiKey, updateKeyUsage, createApiKey } = require('../api/auth');
const config = require('./config');

let discordLogger = null;

function setDiscordLogger(logger) {
  discordLogger = logger;
}

async function handleDecryptCommand(interaction) {
  const file = interaction.options.getAttachment('file');
  const cfxKey = interaction.options.getString('cfx_key');
  const userId = interaction.user.id;
  const userCredits = getUserCredits(userId);
  const userSubscription = getUserSubscription(userId);
  const hasValidSub = hasValidSubscription(userId);

  if (!canUserDecrypt(userId)) {
    let description = `You need **1 credit** or an active subscription to decrypt files.\n\n**Your current balance:** ${userCredits} credits\n`;
    
    if (userSubscription) {
      const subType = userSubscription.type;
      const expiryText = userSubscription.type === 'lifetime' ? 'Never' : 
                        userSubscription.expiresAt ? new Date(userSubscription.expiresAt).toLocaleDateString() : 'N/A';
      description += `**Subscription:** ${subType} (${userSubscription.isActive ? 'Active' : 'Inactive'})\n`;
      description += `**Expires:** ${expiryText}\n`;
    } else {
      description += `**Subscription:** None\n`;
    }
    
    description += `\nContact an administrator to get credits or subscription.`;
    
    const noAccessEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription(description)
      .setColor(0xff9900)
      .setTimestamp();
    
    if (discordLogger) {
      const reason = userCredits < 1 ? 'Insufficient credits' : 'No valid subscription';
      discordLogger.logAccessDenied(interaction.user.tag, userId, reason);
    }
    
    await interaction.reply({ embeds: [noAccessEmbed], ephemeral: true });
    return;
  }

  let confirmationText = `**File:** ${file.name}\n`;
  
  if (hasValidSub) {
    confirmationText += `**Cost:** Free (using ${userSubscription.type} subscription)\n`;
    confirmationText += `**Your credits:** ${userCredits} (unchanged)\n`;
  } else {
    confirmationText += `**Cost:** 1 credit\n`;
    confirmationText += `**Your credits:** ${userCredits}\n`;
    confirmationText += `**Credits after:** ${userCredits - 1}\n`;
  }
  
  confirmationText += `\nDo you want to proceed with the decryption?`;

  const confirmEmbed = new EmbedBuilder()
    .setTitle('Decrypt Confirmation')
    .setDescription(confirmationText)
    .setColor(0x0099ff)
    .setTimestamp();

  const confirmRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_decrypt')
        .setLabel('Confirm')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('cancel_decrypt')
        .setLabel('Cancel')
        .setStyle(ButtonStyle.Danger)
    );

  const reply = await interaction.reply({ 
    embeds: [confirmEmbed], 
    components: [confirmRow], 
    ephemeral: true,
    fetchReply: true
  });

  console.log(`Waiting for confirmation from user ${interaction.user.tag} (${interaction.user.id})`);

  const filter = (i) => {
    console.log(`Button interaction from ${i.user.tag} (${i.user.id}), customId: ${i.customId}`);
    return i.user.id === interaction.user.id;
  };
  
  try {
    console.log('Starting awaitMessageComponent...');
    
    const confirmation = await reply.awaitMessageComponent({ 
      filter, 
      time: 60000 
    });
    console.log(`Confirmation received: ${confirmation.customId}`);

    if (confirmation.customId === 'cancel_decrypt') {
      const cancelEmbed = new EmbedBuilder()
        .setTitle('Decryption Cancelled')
        .setDescription('Decryption has been cancelled. No credits were charged.')
        .setColor(0xff0000)
        .setTimestamp();
      
      await confirmation.update({ 
        embeds: [cancelEmbed], 
        components: [] 
      });
      return;
    }

    if (confirmation.customId === 'confirm_decrypt') {
      if (!hasValidSub) {
        if (!removeCredits(userId, 1)) {
          const errorEmbed = new EmbedBuilder()
            .setTitle('Credit Deduction Failed')
            .setDescription('Failed to deduct credits. Please try again.')
            .setColor(0xff0000)
            .setTimestamp();
          
          await confirmation.update({ 
            embeds: [errorEmbed], 
            components: [] 
          });
          return;
        }
        
        if (discordLogger) {
          const newBalance = getUserCredits(userId);
          discordLogger.logCreditsRemoved(interaction.user.tag, userId, 1, newBalance, 'Decryption');
        }
      }

      if (discordLogger) {
        const method = hasValidSub ? 'Subscription' : 'Credits';
        discordLogger.logDecryptionStart(interaction.user.tag, userId, file.name, method);
      }
      
      await startDecryption(confirmation, file, cfxKey, hasValidSub);
    }
  } catch (error) {
    if (error.code !== 'InteractionCollectorError') {
      console.error('awaitMessageComponent error:', error.message);
      console.error('Error details:', error);
    } else {
      console.log('User confirmation timed out after 60 seconds');
    }
    
    const timeoutEmbed = new EmbedBuilder()
      .setTitle('Confirmation Timeout')
      .setDescription('Confirmation timed out after 60 seconds. No credits were charged.')
      .setColor(0xff9900)
      .setTimestamp();
    
    await interaction.editReply({ 
      embeds: [timeoutEmbed], 
      components: [] 
    });
  }
}

async function startDecryption(interaction, file, cfxKey, usedSubscription = false) {
  const progressEmbed = new EmbedBuilder()
    .setTitle('🔄 Starting Decryption')
    .setDescription('Initializing decryption process...')
    .setColor(0x0099ff)
    .setTimestamp();

  await interaction.update({ 
    embeds: [progressEmbed], 
    components: [] 
  });

  const sessionDir = path.join(__dirname, '..', '..', 'sessions', interaction.id);
  const uploadsDir = path.join(sessionDir, 'Uploads');
  const resourcesDir = path.join(sessionDir, 'Resources');
  const outputDir = path.join(sessionDir, 'Output');
  const tempDir = path.join(sessionDir, 'TempCompiled');

  try {
    ensureEmptyDir(sessionDir);
    ensureEmptyDir(uploadsDir);
    ensureEmptyDir(resourcesDir);
    ensureEmptyDir(outputDir);
    ensureEmptyDir(tempDir);

    await updateProgress(interaction, '📥 Downloading file...', 0x0099ff);
    
    const uploadedPath = path.join(uploadsDir, file.name);
    console.log("File url: " + file.url)
    await downloadTo(file.url, uploadedPath);

    await updateProgress(interaction, '📂 Extracting files...', 0x0099ff);

    const ext = path.extname(uploadedPath).toLowerCase();
    if (ext === '.zip') {
      extractZipTo(resourcesDir, uploadedPath);
    } else if (ext === '.fxap') {
      const name = path.basename(uploadedPath, ext);
      const target = path.join(resourcesDir, name);
      fs.mkdirSync(target, { recursive: true });
      fs.copyFileSync(uploadedPath, path.join(target, '.fxap'));
    } else {
      throw new Error('Unsupported file type');
    }

    await updateProgress(interaction, '🔐 Processing decryption...', 0x0099ff);

    const decryptor = new FiveMDecryptor(outputDir, tempDir);
    const resourceDirs = findResourceDirs(resourcesDir);

    for (const dir of resourceDirs) {
      const resourceName = path.basename(dir);
      await decryptor.decryptResource(cfxKey, dir, resourceName);
    }

    const filesProduced = dirFileCount(outputDir);
    if (filesProduced === 0) {
      let failDescription = 'No decrypted files were produced. Check CFX key authorization and input structure.';
      
      if (!usedSubscription) {
        failDescription += '\n\n**Your credit has been refunded.**';
        addCredits(interaction.user.id, 1);
      }
      
      if (discordLogger) {
        const method = usedSubscription ? 'Subscription' : 'Credits';
        discordLogger.logDecryptionFailed(interaction.user.tag, interaction.user.id, file.name, 'No files decrypted', method);
      }
      
      const failEmbed = new EmbedBuilder()
        .setTitle('Decryption Failed')
        .setDescription(failDescription)
        .setColor(0xff9900)
        .setTimestamp();
      
      await interaction.editReply({ embeds: [failEmbed] });
      return;
    }

    await updateProgress(interaction, '📦 Creating download package...', 0x0099ff);

    const zipPath = path.join(sessionDir, 'Output.zip');
    await zipDirectory(outputDir, zipPath);
    
    const backupSuccess = createBackup(
      interaction.id,
      interaction.user.tag,
      file.name,
      outputDir,
      cfxKey,
      'Discord Bot Interface',
      false
    );
    
    if (backupSuccess) {
      console.log(`Backup created for user ${interaction.user.tag} (${interaction.user.id})`);
    } else {
      console.log(`Backup failed for user ${interaction.user.tag} (${interaction.user.id})`);
    }
    
    cleanOldBackups(30);

    const downloadUrl = `https://portal.allgamers.dev/`;
    
    if (discordLogger) {
      const method = usedSubscription ? 'Subscription' : 'Credits';
      discordLogger.logDecryptionSuccess(interaction.user.tag, interaction.user.id, file.name, interaction.id, method);
    }
    
    const doneEmbed = new EmbedBuilder()
      .setTitle('Decryption Complete')
      .setDescription(`Your files have been successfully decrypted!\n\n**Session ID:** \`${interaction.id}\`\n**Download Portal:** ${downloadUrl}\n\n**Instructions:**\n1. Visit the download portal\n2. Enter your session ID\n3. Click "Check Session" and download\n\n**Important:** Files are deleted after first download.`)
      .setColor(0x00ff00)
      .setTimestamp();
    
    await interaction.editReply({ embeds: [doneEmbed] });
  } catch (error) {
    let errorDescription = `Error: ${error.message}`;
    
    if (!usedSubscription) {
      errorDescription += '\n\n**Your credit has been refunded.**';
      addCredits(interaction.user.id, 1);
    }
    
    if (discordLogger) {
      const method = usedSubscription ? 'Subscription' : 'Credits';
      discordLogger.logDecryptionFailed(interaction.user.tag, interaction.user.id, file.name, error.message, method);
    }
    
    const errorEmbed = new EmbedBuilder()
      .setTitle('Decryption Failed')
      .setDescription(errorDescription)
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.editReply({ embeds: [errorEmbed] });
  }
}

async function updateProgress(interaction, message, color) {
  const progressEmbed = new EmbedBuilder()
    .setTitle('🔄 Processing')
    .setDescription(message)
    .setColor(color)
    .setTimestamp();

  try {
    await interaction.editReply({ embeds: [progressEmbed] });
  } catch (error) {
    console.log('Progress update failed:', error.message);
  }
}

async function handleCreditsCommand(interaction) {
  const userId = interaction.user.id;
  const credits = getUserCredits(userId);
  const subscription = getUserSubscription(userId);
  const hasValidSub = hasValidSubscription(userId);
  
  let description = `**Current Balance:** ${credits} credits\n`;
  
  if (subscription) {
    const subType = subscription.type;
    const expiryText = subscription.type === 'lifetime' ? 'Never' : 
                      subscription.expiresAt ? new Date(subscription.expiresAt).toLocaleDateString() : 'N/A';
    description += `**Subscription:** ${subType} (${subscription.isActive ? 'Active' : 'Inactive'})\n`;
    description += `**Expires:** ${expiryText}\n\n`;
    
    if (hasValidSub) {
      description += `*You have an active subscription - decryptions are free!*`;
    } else {
      description += `*Your subscription has expired - each decryption costs 1 credit*`;
    }
  } else {
    description += `**Subscription:** None\n\n*Each decryption costs 1 credit*`;
  }
  
  const creditsEmbed = new EmbedBuilder()
    .setTitle('Your Account Status')
    .setDescription(description)
    .setColor(0x0099ff)
    .setTimestamp();

  await interaction.reply({ embeds: [creditsEmbed], ephemeral: true });
}

async function handleAddCreditsCommand(interaction) {
  if (!config.ADMIN_USERS.includes(interaction.user.id)) {
    const noPermEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription('You do not have permission to use this command.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noPermEmbed], ephemeral: true });
    return;
  }

  const targetUser = interaction.options.getUser('user');
  const amount = interaction.options.getInteger('amount');
  
      if (addCredits(targetUser.id, amount)) {
      const newBalance = getUserCredits(targetUser.id);
      
      if (discordLogger) {
        discordLogger.logCreditsAdded(targetUser.tag, targetUser.id, amount, newBalance, interaction.user.tag);
      }
      
      const successEmbed = new EmbedBuilder()
        .setTitle('Credits Added')
        .setDescription(`**User:** ${targetUser.tag}\n**Added:** ${amount} credits\n**New Balance:** ${newBalance} credits`)
        .setColor(0x00ff00)
        .setTimestamp();
      
      await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    } else {
    const errorEmbed = new EmbedBuilder()
      .setTitle('Error')
      .setDescription('Failed to add credits. Please try again.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
  }
}

async function handleSetCreditsCommand(interaction) {
  if (!config.ADMIN_USERS.includes(interaction.user.id)) {
    const noPermEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription('You do not have permission to use this command.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noPermEmbed], ephemeral: true });
    return;
  }

  const targetUser = interaction.options.getUser('user');
  const amount = interaction.options.getInteger('amount');
  
      if (setCredits(targetUser.id, amount)) {
      if (discordLogger) {
        const oldBalance = getUserCredits(targetUser.id);
        const change = amount - oldBalance;
        if (change > 0) {
          discordLogger.logCreditsAdded(targetUser.tag, targetUser.id, change, amount, interaction.user.tag);
        } else if (change < 0) {
          discordLogger.logCreditsRemoved(targetUser.tag, targetUser.id, Math.abs(change), amount, 'Admin set');
        }
      }
      
      const successEmbed = new EmbedBuilder()
        .setTitle('Credits Set')
        .setDescription(`**User:** ${targetUser.tag}\n**New Balance:** ${amount} credits`)
        .setColor(0x00ff00)
        .setTimestamp();
      
      await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    } else {
    const errorEmbed = new EmbedBuilder()
      .setTitle('Error')
      .setDescription('Failed to set credits. Please try again.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
  }
}

async function handleApiKeyCreateCommand(interaction) {
  if (!config.ADMIN_USERS.includes(interaction.user.id)) {
    const noPermEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription('You do not have permission to use this command.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noPermEmbed], ephemeral: true });
    return;
  }

  const name = interaction.options.getString('name');
  const customKey = interaction.options.getString('key');
  const subscriptionType = interaction.options.getString('subscription') || 'monthly';
  const monthsValid = interaction.options.getInteger('months') || 1;

  try {
    let apiKey;
    if (customKey) {
      const fs = require('fs');
      const path = require('path');
      const dbPath = path.join(__dirname, '..', 'database', 'api-keys.json');
      const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      
      if (db.keys[customKey]) {
        const errorEmbed = new EmbedBuilder()
          .setTitle('API Key Creation Failed')
          .setDescription('This API key already exists!')
          .setColor(0xff0000)
          .setTimestamp();
        
        await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        return;
      }
      
      let expiresAt = null;
      if (subscriptionType === 'monthly') {
        const expiryDate = new Date();
        expiryDate.setMonth(expiryDate.getMonth() + monthsValid);
        expiresAt = expiryDate.toISOString();
      }
      
      db.keys[customKey] = {
        name,
        subscriptionType,
        expiresAt,
        lastUsed: null,
        requestCount: 0,
        isActive: true,
        createdAt: new Date().toISOString()
      };
      
      fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
      apiKey = customKey;
    } else {
      apiKey = createApiKey(name, subscriptionType, monthsValid);
    }

    const expiryText = subscriptionType === 'lifetime' ? 'Never' : 
                     subscriptionType === 'monthly' ? `${monthsValid} month(s) from now` : 'N/A';

    const successEmbed = new EmbedBuilder()
      .setTitle('API Key Created')
      .setDescription(`**API Key:** \`${apiKey}\`\n**Name:** ${name}\n**Subscription Type:** ${subscriptionType}\n**Expires:** ${expiryText}`)
      .setColor(0x00ff00)
      .setTimestamp();
    
    await interaction.reply({ embeds: [successEmbed], ephemeral: true });
  } catch (error) {
    const errorEmbed = new EmbedBuilder()
      .setTitle('API Key Creation Failed')
      .setDescription('An error occurred while creating the API key.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
  }
}

async function handleApiKeyListCommand(interaction) {
  if (!config.ADMIN_USERS.includes(interaction.user.id)) {
    const noPermEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription('You do not have permission to use this command.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noPermEmbed], ephemeral: true });
    return;
  }

  try {
    const fs = require('fs');
    const path = require('path');
    const dbPath = path.join(__dirname, '..', 'database', 'api-keys.json');
    const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
    
    const keys = Object.keys(db.keys);
    
    if (keys.length === 0) {
      const noKeysEmbed = new EmbedBuilder()
        .setTitle('API Keys')
        .setDescription('No API keys found.')
        .setColor(0xff9900)
        .setTimestamp();
      
      await interaction.reply({ embeds: [noKeysEmbed], ephemeral: true });
      return;
    }

    let description = '';
    keys.slice(0, 10).forEach(key => {
      const data = db.keys[key];
      const shortKey = key.length > 20 ? key.substring(0, 20) + '...' : key;
      const expiryStatus = data.subscriptionType === 'lifetime' ? 'Never' :
                          data.expiresAt ? new Date(data.expiresAt).toLocaleDateString() : 'N/A';
      
      description += `**${shortKey}**\n`;
      description += `Name: ${data.name}\n`;
      description += `Subscription: ${data.subscriptionType || 'legacy'}\n`;
      description += `Expires: ${expiryStatus}\n`;
      description += `Active: ${data.isActive}\n`;
      description += `Last Used: ${data.lastUsed || 'Never'}\n\n`;
    });

    if (keys.length > 10) {
      description += `... and ${keys.length - 10} more keys`;
    }

    const listEmbed = new EmbedBuilder()
      .setTitle(`API Keys (${keys.length} total)`)
      .setDescription(description)
      .setColor(0x0099ff)
      .setTimestamp();
    
    await interaction.reply({ embeds: [listEmbed], ephemeral: true });
  } catch (error) {
    const errorEmbed = new EmbedBuilder()
      .setTitle('Error')
      .setDescription('Failed to load API keys.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
  }
}

async function handleApiKeyRemoveCommand(interaction) {
  if (!config.ADMIN_USERS.includes(interaction.user.id)) {
    const noPermEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription('You do not have permission to use this command.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noPermEmbed], ephemeral: true });
    return;
  }

  const apiKey = interaction.options.getString('key');

  try {
    const fs = require('fs');
    const path = require('path');
    const dbPath = path.join(__dirname, '..', 'database', 'api-keys.json');
    const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
    
    if (!db.keys[apiKey]) {
      const notFoundEmbed = new EmbedBuilder()
        .setTitle('API Key Not Found')
        .setDescription('The specified API key does not exist.')
        .setColor(0xff9900)
        .setTimestamp();
      
      await interaction.reply({ embeds: [notFoundEmbed], ephemeral: true });
      return;
    }

    const keyName = db.keys[apiKey].name;
    delete db.keys[apiKey];
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

    const successEmbed = new EmbedBuilder()
      .setTitle('API Key Removed')
      .setDescription(`**API Key:** \`${apiKey}\`\n**Name:** ${keyName}`)
      .setColor(0x00ff00)
      .setTimestamp();
    
    await interaction.reply({ embeds: [successEmbed], ephemeral: true });
  } catch (error) {
    const errorEmbed = new EmbedBuilder()
      .setTitle('Error')
      .setDescription('Failed to remove API key.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
  }
}

async function handleApiKeyInfoCommand(interaction) {
  if (!config.ADMIN_USERS.includes(interaction.user.id)) {
    const noPermEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription('You do not have permission to use this command.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noPermEmbed], ephemeral: true });
    return;
  }

  const apiKey = interaction.options.getString('key');
  const keyData = validateApiKey(apiKey);

  if (!keyData) {
    const notFoundEmbed = new EmbedBuilder()
      .setTitle('API Key Not Found')
      .setDescription('The specified API key does not exist.')
      .setColor(0xff9900)
      .setTimestamp();
    
    await interaction.reply({ embeds: [notFoundEmbed], ephemeral: true });
    return;
  }

  const expiryStatus = keyData.subscriptionType === 'lifetime' ? 'Never' :
                       keyData.expiresAt ? new Date(keyData.expiresAt).toLocaleString() : 'N/A';

  const infoEmbed = new EmbedBuilder()
    .setTitle('API Key Information')
    .setDescription(`**API Key:** \`${apiKey}\`\n**Name:** ${keyData.name}\n**Subscription Type:** ${keyData.subscriptionType || 'legacy'}\n**Expires:** ${expiryStatus}\n**Request Count:** ${keyData.requestCount}\n**Active:** ${keyData.isActive}\n**Created:** ${keyData.createdAt}\n**Last Used:** ${keyData.lastUsed || 'Never'}`)
    .setColor(0x0099ff)
    .setTimestamp();
  
  await interaction.reply({ embeds: [infoEmbed], ephemeral: true });
}

async function handleSubscriptionAddCommand(interaction) {
  if (!config.ADMIN_USERS.includes(interaction.user.id)) {
    const noPermEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription('You do not have permission to use this command.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noPermEmbed], ephemeral: true });
    return;
  }

  const targetUser = interaction.options.getUser('user');
  const subscriptionType = interaction.options.getString('type');
  const duration = interaction.options.getInteger('duration') || 1;

      try {
      if (setSubscription(targetUser.id, subscriptionType, duration)) {
        if (discordLogger) {
          discordLogger.logSubscriptionAdded(targetUser.tag, targetUser.id, subscriptionType, duration, interaction.user.tag);
        }
        
        const expiryText = subscriptionType === 'lifetime' ? 'Never' :
                          subscriptionType === 'monthly' ? `${duration} month(s) from now` :
                          subscriptionType === 'weekly' ? `${duration} week(s) from now` : 'N/A';

        const successEmbed = new EmbedBuilder()
          .setTitle('Subscription Added')
          .setDescription(`**User:** ${targetUser.tag}\n**Type:** ${subscriptionType}\n**Duration:** ${duration}\n**Expires:** ${expiryText}`)
          .setColor(0x00ff00)
          .setTimestamp();
        
        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
      } else {
      const errorEmbed = new EmbedBuilder()
        .setTitle('Error')
        .setDescription('Failed to add subscription. Please try again.')
        .setColor(0xff0000)
        .setTimestamp();
      
      await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  } catch (error) {
    const errorEmbed = new EmbedBuilder()
      .setTitle('Subscription Creation Failed')
      .setDescription('An error occurred while creating the subscription.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
  }
}

async function handleSubscriptionRemoveCommand(interaction) {
  if (!config.ADMIN_USERS.includes(interaction.user.id)) {
    const noPermEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription('You do not have permission to use this command.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noPermEmbed], ephemeral: true });
    return;
  }

  const targetUser = interaction.options.getUser('user');
  const subscription = getUserSubscription(targetUser.id);

  if (!subscription) {
    const noSubEmbed = new EmbedBuilder()
      .setTitle('No Subscription Found')
      .setDescription(`${targetUser.tag} does not have an active subscription.`)
      .setColor(0xff9900)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noSubEmbed], ephemeral: true });
    return;
  }

      if (removeSubscription(targetUser.id)) {
      if (discordLogger) {
        discordLogger.logSubscriptionRemoved(targetUser.tag, targetUser.id, subscription.type, interaction.user.tag);
      }
      
      const successEmbed = new EmbedBuilder()
        .setTitle('Subscription Removed')
        .setDescription(`**User:** ${targetUser.tag}\n**Previous Type:** ${subscription.type}`)
        .setColor(0x00ff00)
        .setTimestamp();
      
      await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    } else {
    const errorEmbed = new EmbedBuilder()
      .setTitle('Error')
      .setDescription('Failed to remove subscription.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
  }
}

async function handleSubscriptionInfoCommand(interaction) {
  if (!config.ADMIN_USERS.includes(interaction.user.id)) {
    const noPermEmbed = new EmbedBuilder()
      .setTitle('Access Denied')
      .setDescription('You do not have permission to use this command.')
      .setColor(0xff0000)
      .setTimestamp();
    
    await interaction.reply({ embeds: [noPermEmbed], ephemeral: true });
    return;
  }

  const targetUser = interaction.options.getUser('user');
  const credits = getUserCredits(targetUser.id);
  const subscription = getUserSubscription(targetUser.id);
  const hasValidSub = hasValidSubscription(targetUser.id);

  let description = `**User:** ${targetUser.tag}\n**Credits:** ${credits}\n`;
  
  if (subscription) {
    const expiryText = subscription.type === 'lifetime' ? 'Never' : 
                      subscription.expiresAt ? new Date(subscription.expiresAt).toLocaleDateString() : 'N/A';
    description += `**Subscription Type:** ${subscription.type}\n`;
    description += `**Status:** ${subscription.isActive ? 'Active' : 'Inactive'}\n`;
    description += `**Expires:** ${expiryText}\n`;
    description += `**Created:** ${new Date(subscription.createdAt).toLocaleDateString()}\n`;
    description += `**Valid:** ${hasValidSub ? 'Yes' : 'No'}`;
  } else {
    description += `**Subscription:** None`;
  }

  const infoEmbed = new EmbedBuilder()
    .setTitle('User Account Information')
    .setDescription(description)
    .setColor(0x0099ff)
    .setTimestamp();
  
  await interaction.reply({ embeds: [infoEmbed], ephemeral: true });
}

async function handleInteraction(interaction) {
  if (!interaction.isChatInputCommand()) return;
  
  switch (interaction.commandName) {
    case 'decrypt':
      await handleDecryptCommand(interaction);
      break;
    case 'credits':
      await handleCreditsCommand(interaction);
      break;
    case 'addcredits':
      await handleAddCreditsCommand(interaction);
      break;
    case 'setcredits':
      await handleSetCreditsCommand(interaction);
      break;
    case 'subscription-add':
      await handleSubscriptionAddCommand(interaction);
      break;
    case 'subscription-remove':
      await handleSubscriptionRemoveCommand(interaction);
      break;
    case 'subscription-info':
      await handleSubscriptionInfoCommand(interaction);
      break;
    case 'apikey-create':
      await handleApiKeyCreateCommand(interaction);
      break;
    case 'apikey-list':
      await handleApiKeyListCommand(interaction);
      break;
    case 'apikey-remove':
      await handleApiKeyRemoveCommand(interaction);
      break;
    case 'apikey-info':
      await handleApiKeyInfoCommand(interaction);
      break;
  }
}

module.exports = {
  handleInteraction,
  setDiscordLogger
};