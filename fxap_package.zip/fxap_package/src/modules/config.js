module.exports = {
  TOKEN: "",
  CLIENT_ID: "",
  GUILD_ID: "",
  
  KEYMASTER_URL: 'https://keymaster.fivem.net/api/validate',
  
  CRYPTO_KEYS: {
    DEFAULT_KEY: Buffer.from([
      0xb3, 0xcb, 0x2e, 0x04, 0x87, 0x94, 0xd6, 0x73, 0x08, 0x23, 0xc4, 0x93, 0x7a, 0xbd, 0x18, 0xad,
      0x6b, 0xe6, 0xdc, 0xb3, 0x91, 0x43, 0x0d, 0x28, 0xf9, 0x40, 0x9d, 0x48, 0x37, 0xb9, 0x38, 0xfb
    ]),
    
    AES_KEY: Buffer.from([
      0x7a, 0xba, 0x8d, 0x53, 0x25, 0x5b, 0x0e, 0xfd, 0x16, 0xbd, 0x35, 0x22, 0xa0, 0xb9, 0x26, 0xa5,
      0x61, 0x83, 0x2e, 0xec, 0xa2, 0x4b, 0xfd, 0x56, 0x9e, 0xc0, 0x1d, 0x8f, 0x38, 0x40, 0x54, 0x6d
    ])
  },
  
  HEADERS: {
    FXAP_HEADER: Buffer.from([0x46, 0x58, 0x41, 0x50]),
    LUA_HEADER: Buffer.from([0x1b, 0x4c, 0x75, 0x61, 0x54, 0x00, 0x19, 0x93, 0x0d, 0x0a, 0x1a, 0x0a, 0x04, 0x08, 0x08, 0x78, 0x5])
  },
  
  PATHS: {
    DECOMPILER: './Tools/Decompile/unluac54.jar'
  },
  
  ADMIN_USERS: [ // admin user id-s that can use generate and stuff
    "720723486166745088",
    "982105094160003082"
  ],
  
  LOGGING: {
    ENABLED: true, 
    CHANNEL_ID: "1412112061139390566", /// your log channel
    EVENTS: {
      DECRYPTION_START: true,
      DECRYPTION_SUCCESS: true,
      DECRYPTION_FAILED: true,
      ACCESS_DENIED: true,
      SUBSCRIPTION_ADDED: true,
      SUBSCRIPTION_REMOVED: true,
      CREDITS_ADDED: true,
      CREDITS_REMOVED: true,
      API_KEY_CREATED: true,
      API_KEY_REMOVED: true,
      BACKUP_CREATED: true,
      RATE_LIMIT_EXCEEDED: true
    },
    
    COLORS: {
      SUCCESS: 0x00ff00,    // Green
      ERROR: 0xff0000,      // Red
      WARNING: 0xff9900,    // Orange
      INFO: 0x0099ff,       // Blue
      SUCCESS_DARK: 0x00cc00, // Dark Green
      ERROR_DARK: 0xcc0000    // Dark Red
    }
  }
};
