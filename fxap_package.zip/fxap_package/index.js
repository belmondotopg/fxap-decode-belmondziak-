const { Client, GatewayIntentBits } = require('discord.js');
const config = require('./src/modules/config');
const { registerCommands } = require('./src/modules/commands');
const { handleInteraction, setDiscordLogger } = require('./src/modules/handlers');
const { startServer } = require('./src/server');
const { startApiServer } = require('./src/api/api-server');
const { cleanOldBackups } = require('./src/modules/backup');
const DiscordLogger = require('./src/modules/discord-logger');

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

async function initializeApplication() {
  await startServer();
  await startApiServer();
  await registerCommands();
  
  cleanOldBackups(30);
  
  const discordLogger = new DiscordLogger(client);
  
  const { setDiscordLogger: setBackupLogger } = require('./src/modules/backup');
  const { setDiscordLogger: setRateLimitLogger } = require('./src/api/rate-limit');
  const { setDiscordLogger: setAuthLogger } = require('./src/api/auth');
  
  setDiscordLogger(discordLogger);
  setBackupLogger(discordLogger);
  setRateLimitLogger(discordLogger);
  setAuthLogger(discordLogger);
  
  client.on('clientReady', async () => {
    console.log(`Logged in as ${client.user.tag}`);
    await discordLogger.initialize();
  });

  client.on('interactionCreate', handleInteraction);

  await client.login(config.TOKEN);
}

initializeApplication().catch(console.error);